from enum import Enum


class EventType(Enum):

    """
    needs documentation
    """

    ASSET = "ASSET"
    WORKFLOW = "WORKFLOW"
    THREAT = "THREAT"
    MITIGATION = "MITIGATION"
